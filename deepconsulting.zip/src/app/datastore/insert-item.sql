
-- Set the slug variable to insert
SET @slug = 'foo';
INSERT INTO items (slug) VALUES(@slug);